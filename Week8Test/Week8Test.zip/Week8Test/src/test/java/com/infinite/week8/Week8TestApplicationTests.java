//package com.infinite.week8;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class Week8TestApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
